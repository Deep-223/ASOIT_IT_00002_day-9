let n1 = 20, n2 = 30;
var sum = n1 + n2,
    mul = n1 * n2;
document.write("<br/>Sum:", sum + "</br>Mul:", mul);